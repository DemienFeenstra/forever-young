for i in range(1, 13):
    print(i, "AM")

for i in range(13, 25):
    print(i, "PM")